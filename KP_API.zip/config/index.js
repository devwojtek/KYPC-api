module.exports = {
    'secret': 'itsjustrk',
    'database': 'mongodb://localhost:27017/EMD',
    // 'postgre_connection': {
    //     'host': '127.0.0.1',
    //     'port': 5432,
    //     'database': 'postgres',
    //     'user': 'postgres',
    //     'password': '123456'
    // }
    'postgre_connection': {
        'host': '54.234.222.57',
        'port': 5432,
        'database': 'dds_project_v1',
        'user': 'tom',
        'password': 'ksdmn230sdfk32'
    }
};
